from django.apps import AppConfig


class MycartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MyCart'
